#include <iostream>

using namespace std;

int main() {
  long value1 = 200000;
  long value2;

  long * longPtr;

  longPtr = &value1;
  cout << "Address of variable value1 assigned to pointer variable longPtr." << endl;
  cout << endl;

  cout << "Value of the object pointed to by longPtr: " << *longPtr << endl;
  cout << endl;

  value2 = *longPtr;
  cout << "Value of the object pointed to by longPtr assigned to variable value 2." << endl;
  cout << endl;

  cout << "Value of value2: " << value2 << endl;
  cout << endl;

  cout << "Address of value1: " << &value1 << endl;
  cout << endl;

  cout << "Address stored in longPtr: " << longPtr;
  cout << endl;
}