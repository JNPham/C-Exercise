#include "gamma.h"
#include <iostream>

using namespace std;

int gamma::gammaCount = 0;

gamma::gamma(){
  gammaCount += 1;
  idNumber = gammaCount;
}

gamma::~gamma(){
  cout << "Destroying ID number " << gammaCount << endl;
  gammaCount -= 1;
}

void gamma::showtotal() {
  cout << "Total is " << gammaCount << endl;
}

void gamma::showid() const {
  cout << "ID number is "<< idNumber << endl;
}