#include <iostream>
#include "gamma.h"
using namespace std;

int main() {
  gamma g1;
  gamma::showtotal();

  gamma g2, g3;
  gamma::showtotal();

  g1.showid();
  g2.showid();
  g3.showid();
  cout << "----------end of program----------\n";
  return 0;
}