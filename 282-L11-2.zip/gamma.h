#ifndef GAMMA_H
#define GAMMA_H
#include <iostream>

using namespace std;

class gamma{
  private:
    int idNumber;
  public:
    static int gammaCount;
    gamma();
    ~gamma();
    static void showtotal();
    void showid() const;
};
#endif