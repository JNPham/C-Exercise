#ifndef EMPLOYEE_H
#define EMPLOYEE_H
#include <iostream>
#include <cstring>
#include <vector>
using namespace std;

class Employee {
public:
	enum Sex {M = 'M', F = 'F'};
	const float FACULTY_MONTHLY_SALARY = 5000.00;
	const int STAFF_MONTHLY_HOURS_WORKED = 160;
	Employee();
	Employee(std::string ln, std::string fn, std::string id, char s, std::string bd);
	virtual void putData();
  static void writeData();
  static void readData();
  static void addEmployee();
	virtual void getData();
	void getLastName();
	void setLastName(string ln);
	void getFirstName();
	void setFirstName(string fn);
	void getID();
	void setID(string id);
	void getGender();
	void setGender(Sex s);
	void getDOB();
	void setDOB(string bd);
	virtual double monthlyEarning() = 0;
  static vector<Employee*> employees;
  enum employee_type {tfaculty, tstaff, tpartime};
  static int n;
  virtual employee_type get_type(); //get type
  static void add();
private:
	string lastname;
	string firstname;
	string IDnum;
	Sex sex;
	//char birthdate[20] = "N/A";
	string birthdate;
  //static vector<employee*> employees;
};

#endif