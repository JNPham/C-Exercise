#include <iostream>
#include "Education.h"
#include "Employee.h"
#include "Faculty.h"
#include "Staff.h"
#include "Partime.h"
#include <vector>
#include <typeinfo>
#include <fstream>

int Employee::n;
vector<Employee*> Employee::employees;

int main()
{
	float partTimeMonthlyEarning = 0.00;
	float facultyMonthlyEarning = 0.00;
	float staffMonthlyEarning = 0.00;
	float employeeMonthlyEarning = 0.00;

  //vector<Employee*> Employee::employees;
	//static vector<Employee*> employees;
	Employee::employees.push_back(new Staff("Allen", "Paita", "123", 'M', "2/23/59", 50.00));
	Employee::employees.push_back(new Staff("Zapata", "Steven", "456", 'F', "7/12/64", 35.00));
	Employee::employees.push_back(new Staff("Rios", "Enrique", "789", 'M', "6/2/70", 40.00));
	Employee::employees.push_back(new Faculty("Johnson", "Anne", "243", 'F', "4/27/62", "Full", "Ph.D", "Engineering", 3));
	Employee::employees.push_back(new Faculty("Bouris", "William", "791", 'F', "3/14/75", "Associate", "Ph.D", "English", 1));
	Employee::employees.push_back(new Faculty("Andrade", "Christopher", "623", 'F', "5/22/80", "Assistant", "MS", "Physical Education", 0));
	Employee::employees.push_back(new Partime("Guzman", "Augusto", "455", 'F', "8/10/77", 35.00, 30));
	Employee::employees.push_back(new Partime("Depirro", "Martin", "678", 'F', "9/15/87", 30.00, 15));
	Employee::employees.push_back(new Partime("Aldaco", "Marque", "945", 'M', "11/24/88", 20.00, 35)); 
  Employee::n += 9; 
	for (int i = 0; i < Employee::employees.size(); i++) {
		cout << i + 1 << ".";
		Employee::employees[i]->putData();
    Employee::employee_type etype = Employee::employees[i]->get_type();
		//auto& type = *employees[i];
		//string employeeType = typeid(type).name();
		if (etype == Employee::tpartime) {
			partTimeMonthlyEarning += Employee::employees[i]->monthlyEarning();
		}
		else if (etype == Employee::tfaculty) {
			facultyMonthlyEarning += Employee::employees[i]->monthlyEarning();
		}
		else if (etype == Employee::tstaff) {
			staffMonthlyEarning += Employee::employees[i]->monthlyEarning();
		}
		else {
		}
		employeeMonthlyEarning += Employee::employees[i]->monthlyEarning();

		cout << endl;
	}

	cout << "Total monthly salary for all the part-time staff: $" << partTimeMonthlyEarning << endl;

	cout << "Total monthly salary for faculty: $" << facultyMonthlyEarning << endl;

	cout << "Total monthly salary for all staff: $" << staffMonthlyEarning << endl;

	cout << "Total monthly salary for all employees: $" << employeeMonthlyEarning << endl;
	
	bool cont = true;
	char c;
	while (cont) {
		cout << endl;
		cout << "--------------------------------------------------" << endl;
		cout << "Choose a feature: " << endl;
		cout << "'a' -- add data for an employee \n"
			 << "'d' --display data for all employees \n"
			 << "'w' --write all employee data to file \n"
			 << "'r' --read all employee data from file \n"
			 << "'x' --exit" << endl;
		cin >> c;
		if (c == 'a') {
			cout << "Adding option: " << endl;
			cout << " 'f' to add a Faculty \n"
				 << " 's' to add a Staff \n"
				 << " 'p' to add a Part-time \n";
			char addChoice;
			cin >> addChoice;
			if (addChoice == 'f') {
        Faculty *temp = new Faculty();
				Employee::employees.push_back(temp);
        Employee::employees[Employee::employees.size()-1]->getData();
			}
			else if (addChoice == 's') {
				Staff *temp = new Staff();
				Employee::employees.push_back(temp);
        Employee::employees[Employee::employees.size()-1]->getData();
			}
			else if (addChoice == 'p') {
        Partime *temp = new Partime();
        Employee::employees.push_back(temp);
        Employee::employees[Employee::employees.size()-1]->getData();
			}
			else {
				cout << "Invalid input" << endl;
			}
		}
		else if (c == 'd'){
			for (int i = 0; i < Employee::employees.size(); i++) {
				cout << i + 1 << ".";
				Employee::employees[i]->putData();
				cout << endl;
			}
		}
		else if (c == 'w'){
      Employee::writeData();
		}
		else if (c == 'r'){
      Employee::readData();
		}
		else if (c == 'x') {
			cont = false;
		}
		else {
			cout << "Invalid input" << endl;
		}
	};
	return 0;
}