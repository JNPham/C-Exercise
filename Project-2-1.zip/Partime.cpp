#include "Partime.h"
#include <fstream>

Partime::Partime():Staff() {
	hourperweek = 0;
}
Partime::Partime(std::string ln, std::string fn, std::string id, char s, std::string bd, double hr, int hpw) : Staff(ln, fn, id, s, bd, hr) {
	hourperweek = hpw;
};
void Partime::getData() {
	Staff::getData();
	cout << "Enter hours worked per week: " << endl;
	cin >> hourperweek;
};
void Partime::setHourPerWeek(int hpw) {
	hourperweek = hpw;
};
double Partime::monthlyEarning() {
	return Staff::getHourlyRate() * hourperweek * 4;
};
void Partime::putData() {
	Staff::putData();
	cout << "Hours worked per month: " << hourperweek * 4 << endl;
	cout << "Monthly Salary: $" << monthlyEarning() << endl;
};

//void Partime::writeData() {
  /*fstream dataFile;
  dataFile.open("fdata.txt", ios::app);
  if (!dataFile) {
    cout << "In Partime: Can't open file\n";
  }
  else {
    Staff::writeData();
    dataFile << "Hours worked per month: " << hourperweek * 4 << endl;
    dataFile << "Monthly Salary: $" << monthlyEarning() << endl;
    //dataFile.close();
  } */
//}