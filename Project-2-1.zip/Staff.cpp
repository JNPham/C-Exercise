#include "Staff.h"
#include "Employee.h"
#include <iostream>
#include <fstream>
using namespace std;

Staff::Staff():Employee() {
	hourlyrate = 0;
};

Staff::Staff(std::string ln, std::string fn, std::string id, char s, std::string bd, double hr):Employee(ln, fn, id, s, bd) {
	hourlyrate = hr;
}

void Staff::getData() {
	/*Employee::getFirstName();
	Employee::getLastName();
	Employee::getID();
	Employee::getGender();
	Employee::getDOB();*/
  Employee::getData();
	cout << "Enter hourly rate: " << endl;
	cin >> hourlyrate;
}

double Staff::getHourlyRate() {
	return hourlyrate;
}

void Staff::setData(double hr) {
	hourlyrate = hr;
}

double Staff::monthlyEarning() {
	return hourlyrate * STAFF_MONTHLY_HOURS_WORKED;
}

void Staff::putData() {
	Employee::putData();
	cout << "Full Time" << endl;
	cout << "Monthly Salary: $" << monthlyEarning() << endl;
}

//void Staff::writeData() {
  /*fstream dataFile;
  dataFile.open("fdata.txt", ios::app);
  if (!dataFile) {
    cout << "In Staff: Can't open file\n";
  }
  else {
    Employee::writeData();
    dataFile << "Full Time" << endl;
    dataFile << "Monthly Salary: $" << monthlyEarning() << endl;
    //dataFile << endl;
    //dataFile.close();
  }*/
//}