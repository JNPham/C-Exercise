#include "Employee.h"
#include "Staff.h"
#include "Faculty.h"
#include "Partime.h"
#include <fstream>
#include <vector>

Employee::Employee() {
	lastname = "N/A";
	firstname = "N/A";
	IDnum = "N/A";
	sex = M;
	birthdate = "N/A";
};

Employee::Employee(std::string ln, std::string fn, std::string id, char s, std::string bd) {
	lastname = ln;
	firstname = fn;
	IDnum = id;
	sex = Sex(s);
	string yr = bd.substr(bd.length() - 2, 2);
	birthdate = bd.substr(0, bd.length()-2);
	birthdate += "19" + yr;
};

void Employee::putData(){
	cout << "ID Employee number: " << IDnum << endl;
	cout << "Employee name: " << firstname << " " << lastname << endl;
	cout << "Birth date: " << birthdate << endl;
};

void Employee::writeData(){
  int size; 
  cout << "Writing " << employees.size() << " employees.\n"; 
  ofstream ouf; //open ofstream in binary 
  employee_type etype; //type of each employee object 
  ouf.open("EMPLOY.DAT", ios::trunc | ios::binary); 
  if(!ouf) 
    {cout << "\nCan’t open file\n"; return; } 
  for(int j=0; j<employees.size(); j++) //for every employee object 
    { //get its type 
    etype = employees[j]->get_type(); 
  //write type to file 
    ouf.write((char*)&etype, sizeof(etype) ); 
    switch(etype) //find its size 
    { 
      case tfaculty: size=sizeof(Faculty); break; 
      case tstaff: size=sizeof(Staff); break; 
      case tpartime: size=sizeof(Partime); break;  
    } //write employee object to file 
    ouf.write( (char*)(employees[j]), size );
  if(!ouf) 
  { cout << "\nCan’t write to file\n"; return; } 
  } 
}

void Employee::readData() {
  int size; //size of employee object 
  employee_type etype; //type of employee 
  ifstream inf; //open ifstream in binary 
  inf.open("EMPLOY.DAT", ios::binary); 
  if(!inf) 
    { cout << "\nCan’t open file\n"; return; } 
  n = 0; //no employees in memory yet 
  while(true) { //read type of next employee 
    inf.read( (char*)&etype, sizeof(etype) ); 
    if( inf.eof() ) //quit loop on eof 
      break; 
    if(!inf) //error reading type 
      { cout << "\nCan’t read type from file\n"; return; } 
    switch(etype) { //make new employee 
      case tfaculty: //of correct type 
        employees[n] = new Faculty; 
        size=sizeof(Faculty); 
        break; 
      case tstaff: 
        employees[n] = new Staff; 
        size=sizeof(Staff); 
        break; 
      case tpartime: 
        employees[n] = new Partime; 
        size=sizeof(Partime); 
        break; 
      default: 
        cout << "\nUnknown type in file\n"; 
        return; 
    } //read data from file into it 
    inf.read( (char*)employees[n], size  ); 
    if(!inf) //error but not eof 
      { cout << "\nCan’t read data from file\n"; return; } 
    n++; //count employee 
  } //end while 
cout << "Reading " << n << " employees\n";
}

void Employee::getData() {
	getLastName();
	getFirstName();
	getID();
	getGender();
	getDOB();
};

void Employee::getLastName() {
	cout << "Enter last name: " << endl;
	cin >> lastname;
};

void Employee::setLastName(string ln) {
	lastname = ln;
};

void Employee::getFirstName() {
	cout << "Enter first name: " << endl;
	cin >> firstname;
};

void Employee::setFirstName(string fn) {
	firstname = fn;
};

void Employee::getID() {
	cout << "Enter ID: " << endl;
	cin >> IDnum;
};

void Employee::setID(string id) {
	IDnum = id;
};

void Employee::getGender() {
	char gender;
	cout << "Enter gender: " << endl;
	cin >> gender;
	sex = (Sex)gender;
};

void Employee::setGender(Sex s) {
	sex = s;
};

void Employee::getDOB() {
	string bd;
	cout << "Enter birth date: " << endl;
	cin >> bd;
	string yr = bd.substr(bd.length() - 2, 2);
	birthdate = bd.substr(0, bd.length() - 2);
	birthdate += "19" + yr;
};

void Employee::setDOB(string bd) {
	birthdate = bd;
};

Employee::employee_type Employee::get_type() { 
  if(typeid(*this) == typeid(Faculty) ) 
    return tfaculty; 
  else if( typeid(*this)==typeid(Staff) ) 
    return tstaff; 
  else if( typeid(*this)==typeid(Partime) ) 
    return tpartime; 
  else { cerr << "\nBad employee type"; exit(1); } 
  return tstaff; 
};

void Employee::add() { 
  char ch; 
  cout << "'f' to add a Faculty" 
          "\n's' to add a Staff" 
          "\n'p' to add a Part-time" 
          "\nEnter selection: "; 
  cin >> ch; 
  switch(ch) { //create specified employee type 
    case 'f': employees[n] = new Faculty; break; 
    case 's': employees[n] = new Staff; break; 
    case 'p': employees[n] = new Partime; break; 
    default: cout << "\nUnknown employee type\n"; return; 
  } 
  employees[n++]->getData(); //get employee data from user 
}