#include <iostream>
#include "Education.h"
#include "Employee.h"
#include "Faculty.h"
#include "Staff.h"
#include "Partime.h"
#include <vector>
#include <typeinfo>

int main()
{
  float partTimeMonthlyEarning = 0.00;
  float facultyMonthlyEarning = 0.00;
  float staffMonthlyEarning = 0.00;
  float employeeMonthlyEarning = 0.00;

	vector<Employee*> employees;
	employees.push_back(new Staff("Allen", "Paita", "123", 'M', "2/23/59", 50.00));
	employees.push_back(new Staff("Zapata", "Steven", "456", 'F', "7/12/64", 35.00));
	employees.push_back(new Staff("Rios", "Enrique", "789", 'M', "6/2/70", 40.00));
	employees.push_back(new Faculty("Johnson", "Anne", "243", 'F', "4/27/62", "Full", "Ph.D", "Engineering",3));
	employees.push_back(new Faculty("Bouris", "William", "791", 'F', "3/14/75", "Associate", "Ph.D", "English", 1));
	employees.push_back(new Faculty("Andrade", "Christopher", "623", 'F', "5/22/80", "Assistant", "MS", "Physical Education", 0));
	employees.push_back(new Partime("Guzman", "Augusto", "455", 'F', "8/10/77", 35.00, 30));
	employees.push_back(new Partime("Depirro", "Martin", "678", 'F', "9/15/87", 30.00, 15));
	employees.push_back(new Partime("Aldaco", "Marque", "945", 'M', "11/24/88", 20.00, 35));
	for (int i = 0; i < employees.size(); i++) {
		cout << i+1 << ".";
		employees[i]->putData();
    auto& type = *employees[i];
    string employeeType = typeid(type).name();
    if(employeeType == "7Partime") {
      partTimeMonthlyEarning += employees[i]->monthlyEarning();
    }
    else if(employeeType == "7Faculty") {
      facultyMonthlyEarning += employees[i]->monthlyEarning();
    }
    else if(employeeType == "5Staff") {
      staffMonthlyEarning += employees[i]->monthlyEarning();
    }
    else {
    }
    employeeMonthlyEarning += employees[i]->monthlyEarning();
    
		cout << endl;
	}

  cout << "Total monthly salary for all the part-time staff: $" << partTimeMonthlyEarning << endl;
  
  cout << "Total monthly salary for faculty: $" << facultyMonthlyEarning << endl;

  cout << "Total monthly salary for all staff: $" << staffMonthlyEarning << endl;

  cout << "Total monthly salary for all employees: $" << employeeMonthlyEarning;

	return 0;
}