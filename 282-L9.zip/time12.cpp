#include "time12.h"
#include "time24.h"
#include <iostream>

using namespace std;

time12::time12() {
  hrs = 0;
  mins = 0;
  pm = false;
};

time12::time12(int h, int m, bool p) {
  hrs = h;
  mins = m;
  pm = p;
};

time12::time12(time24 t24) {
  if(t24.getHours() == 0) {
    hrs = 12;
  }
  else if(t24.getHours() > 12) {
    hrs = t24.getHours() - 12;
  }
  else {
    hrs = t24.getHours();
  }
  mins = t24.getMinutes();
  if(t24.getHours() > 11){
    pm = true;
  }
  else {
    pm = false;
  };
};

void time12::display() const {
  cout << hrs << ':';
  if(mins < 10){
    cout << "0" << mins << ' ';
  }
  else {
    cout << mins << ' ';
  }
  string am_pm = pm ? "p.m." : "a.m.";
  cout << am_pm;
}