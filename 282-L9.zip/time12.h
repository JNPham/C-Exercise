#ifndef TIME12_H
#define TIME12_H
#include <iostream>
#include "time24.h"

using namespace std;

class time12 {
  private:
    bool pm;
    int hrs;
    int mins;
  
  public:
    time12();
    time12(int h, int m, bool p);
    time12(time24 t24);
    void display() const;
};
#endif