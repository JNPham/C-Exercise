#include "time24.h"
#include <iostream>

using namespace std;

time24::time24() {
  hours = 0;
  minutes = 0;
  seconds = 0;
};

time24::time24(int h, int m, int s) {
  hours = h;
  minutes = m;
  seconds = s;
};

void time24::display() const {
  if(hours < 10){
    cout << '0';
  };
  cout << hours << ':';
  if(minutes < 10){
    cout << '0';
  };
  cout << minutes << ':';
  if(seconds < 10){
    cout<<'0';
  }
  cout << seconds;
};

int time24::getHours() {
  return hours;
}

int time24::getMinutes() {
  return minutes;
}