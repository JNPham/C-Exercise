#ifndef TIME24_H
#define TIME24_H
#include <iostream>

using namespace std;

class time24 {
  private:
    int hours;
    int minutes;
    int seconds;
  public:
    time24();
    time24(int h, int m, int s);
    void display() const;
    int getHours();
    int getMinutes();
};
#endif