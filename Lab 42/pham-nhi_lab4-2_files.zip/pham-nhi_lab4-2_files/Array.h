#ifndef ARRAY_H
#define ARRAY_H

#include <iostream>

using namespace std;

class Array {
  private:
    int capacity;
    int size;
    int *arr;
  
  public:
    Array(int c);
    Array();
    ~Array();

    void insert(int num);
    void print();
};

#endif