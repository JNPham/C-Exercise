#include <iostream>
#include "cylinderType.h"

using namespace std;

void cylinderType::print() const {
  cout << "Base Center: ";
  pointType::print();
  cout << endl;
  cout << "Base Radius: " << circleType::getRadius() << endl;
  cout << "Base Circumference: " << circleType::getCircumference() << endl;
  cout << "Base Area: " << circleType::getArea() << endl;
  cout << "Cylinder height: " << height << endl;
  cout << "Cylinder surface area: " << getSurfaceArea() << endl;
  cout << "Cylinder volume: " << getVolume() << endl;
}

void cylinderType::setHeight(double h) {
  height = h;
}

void cylinderType::setBaseCenter(double x, double y) {
  pointType::setPoint(x, y);
}

void cylinderType::setCenterRadiusHeight(double x, double y, double r, double h) {
  pointType::setPoint(x, y);
  circleType::setRadius(r);
  setHeight(h);
}

double cylinderType::getHeight() const {
  return height;
}

double cylinderType::getVolume() const {
  return (3.1416 * radius * radius * height);
}

double cylinderType::getSurfaceArea() const {
  return ((2 * 3.1416 * radius * height) + (2 * 3.1416 * radius * radius));
}

cylinderType::cylinderType(double x, double y, double r, double h):circleType(x,y,r) {
  height = h;
}