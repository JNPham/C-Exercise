#include <iostream>
#include "Fraction.h"

using namespace std;

Fraction result;
Fraction& multiplyFract(Fraction& fr1, Fraction& fr2) {
  result.setNumer(fr1.getNumer() * fr2.getNumer());
  result.setDenom(fr1.getDenom() * fr2.getDenom());

  return result;
}

int main() {
  Fraction fract1;
  Fraction fract2(14, 21);
  Fraction fract3(11, -8);
  Fraction fract4(fract3);
  Fraction fract5(2, 0);

  cout << "Printing four fractions after constructed: " << endl;
  cout << "fract1: ";
  fract1.print();
  cout << endl;
  cout << "fract2: ";
  fract2.print();
  cout << endl;
  cout << "fract3: ";
  fract3.print();
  cout << endl;
  cout << "fract4: ";
  fract4.print();
  cout << endl;
  cout << "fract5: ";
  fract5.print();
  cout << endl;
  cout << endl;

  cout << "Changing the first two fractions and printing them: ";
  cout << endl;
  fract1.setNumer(4);
  cout << "fract1: ";
  fract1.print();
  cout << endl;
  fract2.setDenom(-5);
  cout << "fract2: ";
  fract2.print();
  cout << endl;
  cout << endl;

  cout << "Testing the changes in two fractions: " << endl;
  cout << "fract1 numerator: " << fract1.getNumer() << endl;
  cout << "fract2 numerator: " << fract2.getDenom() << endl;
  cout << endl;

  fract1.setNumer(1);
  fract1.setDenom(2);
  fract2.setNumer(2);
  fract2.setDenom(3);

  Fraction fract6 = multiplyFract(fract1, fract2);
  cout << "Product of " << fract1.getNumer() << "/" << fract1.getDenom() << " * " << fract2.getNumer() << "/" << fract2.getDenom() << " is: ";
  fract6.print();

  return 0;
}